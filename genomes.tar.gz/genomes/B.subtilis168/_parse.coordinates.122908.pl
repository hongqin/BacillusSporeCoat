#parse genome coordiantes for all features in Bsu168 genome

use strict; use warnings;
use lib '/home/hqin/lib/perl'; use moran; 

my $debug = 0;

my $infile = "SLR16.1_embl.txt";
#my $infile = "test.txt";
open(IN,"<$infile");
my @lines = <IN>;
close(IN);

@lines = grep(/^FT/, @lines);
@lines = splice( @lines, 5 ); #remove unwanted lines on the front

if ($debug>9) { @lines = splice( @lines, 0, 1000); }

my @originallines = @lines; 

### find the boundaries of features
my @pos = ();
for( my $i=0; $i<=$#lines; $i++) {
  if ($lines[$i] =~ /FT   CDS|FT   rRNA/ ) {
    push (@pos, $i );
  }
} 
push( @pos, $#lines );


open(OUT, ">Bsu168.features.coor.csv");
for( my $i=0; $i<= $#pos-1; $i++ ) {
 my ($strand, $start, $end) = ();
 @lines = @originallines;
 @lines = splice( @lines, $pos[$i], $pos[$i+1]-$pos[$i]);
 if($debug>10) { print "[".substr($lines[0], 0, 80) ."]\n"; 
   print "There are ". ($#lines + 1) . " lines\n";
 }
 
 my ($el, $type, $rawcoor, @res) = split( /\s+/, $lines[0] );
 if ($rawcoor !~ /join/) {
  if ($rawcoor =~ /complement/ ) {
   $strand = '-';
   $rawcoor =~ s/complement//;
   $rawcoor =~ s/\(//;
   $rawcoor =~ s/\)//;
  } else {
   $strand = '+';
  } 
   ($start, $end) = split( /\.\./, $rawcoor );
    $start =~ s/<//g; #remove a bug in the input file
 } else { #there two join(complement ... lines
   $strand = '-';
   my ($el3, $rawcoor2, @res) = split( /\s+/, $lines[1] );
   $rawcoor = $rawcoor . $rawcoor2;
   $rawcoor =~ s/complement//g;
   $rawcoor =~ s/join//g;
   $rawcoor =~ s/\(//g;
   $rawcoor =~ s/\)//g;
   $rawcoor =~ s/\s+//g;
   my (@num) = split( /\.\.|\,/, $rawcoor );
   @num = sort( @num);
   ($start, $end) = ($num[0], $num[$#num]);
 }
  
 my @tmp = grep( /\/acc_num=/, @lines);
 my ($el2, $bg, @res2 ) = split( /\/acc_num=/, $tmp[0] );
 $bg =~ s/\"|\n//g;

 print OUT "$bg\t$type\t$strand\t$start\t$end\n";

}

close(OUT);

exit;
