run codeml and CONSEL topology tests. 
